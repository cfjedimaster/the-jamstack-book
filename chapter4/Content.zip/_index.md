---
title: LOLCODE
---

![LOLCODE](/images/lolcode.png)

# LOLCODE

An esoteric programming language