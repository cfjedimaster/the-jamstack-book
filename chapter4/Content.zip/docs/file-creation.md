---
title: File Creation
weight: 3
---

*(modified from 1.1)*

All LOLCODE programs must be opened with the command `HAI`. `HAI` should then be followed with the current LOLCODE language version number (1.2, in this case). There is no current standard behavior for implementations to treat the version number, though.

A LOLCODE file is closed by the keyword `KTHXBYE` which closes the `HAI` code-block.